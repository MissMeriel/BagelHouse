package v1;


/**
 *  This program creates an instance of the OrderCalculatorGUI
 *  class, which displays the GUI for Della's House of Bagels
 */

public class Driver
{
   public static void main(String[] args)
   {
      new OrderCalculatorGUI();
   }
}
